import React, { useState, useEffect } from "react";

function TrialBalance() {
  const [supplierDue, setSupplierDue] = useState(0.0);
  const [customerDue, setCustomerDue] = useState(0.0);
  const [accountBalances, setAccountBalances] = useState([]);
  const [totalDebit, setTotalDebit] = useState(0);
  const [totalCredit, setTotalCredit] = useState(0);
  const [currentDate, setCurrentDate] = useState("");

  useEffect(() => {
    const today = new Date();
    setCurrentDate(today.toLocaleDateString());

    const fetchData = async () => {
      try {
        const balances = await getAccountBalances();
        setAccountBalances(balances);
        calculateTotals(balances);
      } catch (error) {
        console.error("Error fetching account balances:", error);
      }
    };

    fetchData();
  }, []);

  const getAccountBalances = async () => {
    const response = await fetch(
      `${process.env.REACT_APP_BASE_URL}/trialBalance/getall`
    );
    if (!response.ok) {
      throw new Error("Network response was not ok");
    }
    return await response.json();
  };

  const calculateTotals = (balances) => {
    const debitSum = balances.reduce((acc, balance) => acc + balance.debit, 0);
    const creditSum = balances.reduce(
      (acc, balance) => acc + balance.credit,
      0
    );
    setTotalDebit(debitSum);
    setTotalCredit(creditSum);

    const supplierDue = balances.reduce(
      (acc, balance) =>
        balance.name === "Accounts Payable" ? acc + balance.credit : acc,
      0
    );
    const customerDue = balances.reduce(
      (acc, balance) =>
        balance.name === "Accounts Receivable" ? acc + balance.debit : acc,
      0
    );

    setSupplierDue(supplierDue);
    setCustomerDue(customerDue);
  };

  const handlePrint = () => {
    const printWindow = window.open("", "_blank", "width=800,height=600");

    // Construct the HTML content for printing
    const printContent = `
      <html>
        <head>
          <title>Trial Balance</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            th { background-color: #f2f2f2; }
            th, td { text-align: left; }
            h2 { text-align: center; }
          </style>
        </head>
        <body>
          <h2>Awesome Shop - Trial Balance - ${currentDate}</h2>
          <table>
            <thead>
              <tr>
                <th>Trial Balance</th>
                <th>Debit</th>
                <th>Credit</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>Supplier Due:</th>
                <td>&nbsp;</td>
                <td>${supplierDue.toFixed(2)}</td>
              </tr>
              <tr>
                <th>Customer Due:</th>
                <td>${customerDue.toFixed(2)}</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th>Account Balances:</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              ${accountBalances
                .map(
                  (balance) => `
                <tr>
                  <th>${balance.name}:</th>
                  <td>${balance.debit.toFixed(2)}</td>
                  <td>${balance.credit.toFixed(2)}</td>
                </tr>
              `
                )
                .join("")}
            </tbody>
            <tfoot>
              <tr class="bg-gray">
                <th>Total</th>
                <td>${totalDebit.toFixed(2)}</td>
                <td>${totalCredit.toFixed(2)}</td>
              </tr>
            </tfoot>
          </table>
        </body>
      </html>
    `;

    // Write the content to the new window
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  };

  return (
    <div className="wrapper">
      <div className="content-wrapper">
        <section className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-12 col-md-6">
                <h1 className=" all-heading">Trial Balance</h1>
                <span className="d-inline d-md-block sub-heading">
                  Manage balance
                </span>
              </div>
            </div>
          </div>
        </section>

        <section className="content">
          <div className="container-fluid">
            <div className="card cardHover rounded-4 border-0">
              <div className="card-body">
                <div className="box box-solid" id="printSection">
                  <div className="box-header">
                    <h3 className="box-title">
                      Awesome Shop - Trial Balance -{" "}
                      <span id="hidden_date">{currentDate}</span>
                    </h3>
                  </div>
                  <div className="box-body">
                    <table className="table ">
                      <thead>
                        <tr>
                          <th>Trial Balance</th>
                          <th>Debit</th>
                          <th>Credit</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th>Supplier Due:</th>
                          <td>&nbsp;</td>
                          <td>
                            <span className="remote-data" id="supplier_due">
                              ${supplierDue.toFixed(2)}
                            </span>
                          </td>
                        </tr>
                        <tr>
                          <th>Customer Due:</th>
                          <td>
                            <span className="remote-data" id="customer_due">
                              ${customerDue.toFixed(2)}
                            </span>
                          </td>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <th>Account Balances:</th>
                          <td>&nbsp;</td>
                          <td>&nbsp;</td>
                        </tr>
                        {accountBalances.map((balance, index) => (
                          <tr key={index}>
                            <th>{balance.name}:</th>
                            <td>${balance.debit.toFixed(2)}</td>
                            <td>${balance.credit.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="bg-gray">
                          <th>Total</th>
                          <td>${totalDebit.toFixed(2)}</td>
                          <td>${totalCredit.toFixed(2)}</td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                  <div className="box-footer">
                    <button
                      type="button"
                      className="btn btn-success"
                      onClick={handlePrint}
                    >
                      <i className="fa fa-print" /> Print
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default TrialBalance;
