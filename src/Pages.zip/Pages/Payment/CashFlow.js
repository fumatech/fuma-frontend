import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../assets/dist/css/adminlte.min.css";
import "../../assets/plugins/fontawesome-free/css/all.min.css";
import "../../assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css";
import "../../assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css";
import "../../assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css";
import { saveAs } from "file-saver";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import $ from "jquery";

const CashFlow = () => {
  const [transactions, setTransactions] = useState([]);
  const [columnsVisibility, setColumnsVisibility] = useState({
    date: true,
    account: true,
    description: true,
    paymentMethod: true,
    paymentDetails: true,
    debit: true,
    credit: true,
    accountBalance: true,
    totalBalance: true,
    action: true,
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(25);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BASE_URL}/cashflow/getall`
        );
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setTransactions(data);
        } else {
          console.error("Fetched data is not an array");
          setTransactions([]);
        }
      } catch (error) {
        console.error("Error fetching transactions:", error);
        setTransactions([]);
      }

      const script = document.createElement("script");
      script.src = "js/JqueryContent.js";
      script.async = true;

      document.body.appendChild(script);

      return () => {
        document.body.removeChild(script);
      };
    };

    fetchTransactions();
  }, []);

  const exportCSV = () => {
    const csvData = transactions.map((transaction) => ({
      Date: transaction.date,
      Account: transaction.account,
      Description: transaction.description,
      PaymentMethod: transaction.paymentMethod,
      PaymentDetails: transaction.paymentDetails,
      Debit: transaction.debit,
      Credit: transaction.credit,
      AccountBalance: transaction.accountBalance,
      TotalBalance: transaction.totalBalance,
    }));

    const csv = [
      [
        "Date",
        "Account",
        "Description",
        "Payment Method",
        "Payment Details",
        "Debit",
        "Credit",
        "Account Balance",
        "Total Balance",
      ],
      ...csvData.map((row) => Object.values(row)),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    saveAs(blob, "cashflow.csv");
  };

  const exportExcel = () => {
    const ws = XLSX.utils.json_to_sheet(
      transactions.map((transaction) => ({
        Date: transaction.date,
        Account: transaction.account,
        Description: transaction.description,
        PaymentMethod: transaction.paymentMethod,
        PaymentDetails: transaction.paymentDetails,
        Debit: transaction.debit,
        Credit: transaction.credit,
        AccountBalance: transaction.accountBalance,
        TotalBalance: transaction.totalBalance,
      }))
    );
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "CashFlow");
    XLSX.writeFile(wb, "cashflow.xlsx");
  };

  const exportPDF = () => {
    const doc = new jsPDF();

    // Define the column headers
    const headers = [
      "Date",
      "Account",
      "Description",
      "Payment Method",
      "Payment Details",
      "Debit",
      "Credit",
      "Account Balance",
      "Total Balance",
    ];

    // Prepare the data
    const body = transactions
      .slice(startIndex, endIndex)
      .map((transaction) => [
        transaction.date,
        transaction.account,
        transaction.description,
        transaction.paymentMethod,
        transaction.paymentDetails,
        transaction.debit,
        transaction.credit,
        transaction.accountBalance,
        transaction.totalBalance,
      ]);

    // Add some space before the table
    doc.text("Transactions List", 14, 20); // Title with a slight offset
    doc.setFontSize(12);
    doc.text("Below is the list of transactions:", 14, 30);

    // Generate the PDF table with custom styles
    doc.autoTable({
      head: [headers],
      body: body,
      theme: "grid",
      styles: {
        fontSize: 10,
        cellPadding: 3,
        valign: "middle",
        halign: "center",
        overflow: "linebreak",
      },
      headStyles: {
        fillColor: [22, 160, 133], // Bootstrap success color
        textColor: [255, 255, 255], // White text
        fontStyle: "bold",
      },
      alternateRowStyles: {
        fillColor: [240, 240, 240], // Light gray for alternate rows
      },
      margin: { top: 50 }, // Increase top margin for more space above the table
    });

    // Calculate totals for debit and credit
    const totalDebit = transactions
      .reduce((acc, transaction) => acc + (transaction.debit || 0), 0)
      .toFixed(2);
    const totalCredit = transactions
      .reduce((acc, transaction) => acc + (transaction.credit || 0), 0)
      .toFixed(2);

    // Add totals to the PDF
    doc.text(
      `Total Debit: $${totalDebit}`,
      14,
      doc.autoTable.previous.finalY + 10
    );
    doc.text(
      `Total Credit: $${totalCredit}`,
      14,
      doc.autoTable.previous.finalY + 20
    );

    // Save the PDF
    doc.save("TransactionsList.pdf");
  };

  const printData = () => {
    const printWindow = window.open("", "_blank", "width=800,height=600");

    const tableContent = `
      <html>
        <head>
          <title>Print Cash Flow Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            th { background-color: #f2f2f2; }
            th, td { text-align: left; }
          </style>
        </head>
        <body>
          <h2>Cash Flow Report</h2>
          <table>
            <thead>
              <tr>
                ${columnsVisibility.date ? "<th>Date</th>" : ""}
                ${columnsVisibility.account ? "<th>Account</th>" : ""}
                ${columnsVisibility.description ? "<th>Description</th>" : ""}
                ${
                  columnsVisibility.paymentMethod
                    ? "<th>Payment Method</th>"
                    : ""
                }
                ${
                  columnsVisibility.paymentDetails
                    ? "<th>Payment Details</th>"
                    : ""
                }
                ${columnsVisibility.debit ? "<th>Debit</th>" : ""}
                ${columnsVisibility.credit ? "<th>Credit</th>" : ""}
                ${
                  columnsVisibility.accountBalance
                    ? "<th>Account Balance</th>"
                    : ""
                }
                ${
                  columnsVisibility.totalBalance ? "<th>Total Balance</th>" : ""
                }
              </tr>
            </thead>
            <tbody>
              ${transactions
                .slice(startIndex, endIndex)
                .map(
                  (transaction) => `
                <tr>
                  ${
                    columnsVisibility.date ? `<td>${transaction.date}</td>` : ""
                  }
                  ${
                    columnsVisibility.account
                      ? `<td>${transaction.account}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.description
                      ? `<td>${transaction.description}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.paymentMethod
                      ? `<td>${transaction.paymentMethod}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.paymentDetails
                      ? `<td>${transaction.paymentDetails}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.debit
                      ? `<td>${transaction.debit}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.credit
                      ? `<td>${transaction.credit}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.accountBalance
                      ? `<td>${transaction.accountBalance}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.totalBalance
                      ? `<td>${transaction.totalBalance}</td>`
                      : ""
                  }
                </tr>
              `
                )
                .join("")}
            </tbody>
          </table>
        </body>
      </html>
    `;

    printWindow.document.write(tableContent);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  };

  const handleEntriesChange = (e) => {
    setEntriesPerPage(Number(e.target.value));
    setCurrentPage(1);
  };

  const toggleColumn = (column) => {
    setColumnsVisibility((prev) => ({
      ...prev,
      [column]: !prev[column],
    }));
  };
  const startIndex = (currentPage - 1) * entriesPerPage;
  const endIndex = startIndex + entriesPerPage;

  return (
    <div className="wrapper">
      <div className="content-wrapper">
        <section className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-12 col-md-6">
                <h1 className="all-heading">Cash Flow</h1>
                <span className="d-inline d-md-block sub-heading">
                  Manage Cash Flow Transactions
                </span>
              </div>
            </div>
          </div>
        </section>
        <section className="content">
          <div className="container-fluid">
            <div className="card cardHover rounded-4 border-0">
              <div className="card-body">
                <div className="row mb-3 d-flex align-items-center">
                  <div className="col-12 col-md-auto form-group mb-2 d-flex align-items-center text-bold mt-2 mb-2 mr-2">
                    <label htmlFor="entriesPerPage" className="mb-0 mr-2">
                      Show
                    </label>
                    <select
                      id="entriesPerPage"
                      className="form-control form-control-sm mr-2"
                      value={entriesPerPage}
                      onChange={handleEntriesChange}
                    >
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={75}>75</option>
                      <option value={100}>100</option>
                    </select>
                    Entries
                  </div>

                  <div className="col d-flex flex-wrap align-items-center">
                    <button
                      onClick={exportCSV}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-file-csv"></i> Export CSV
                    </button>

                    <button
                      onClick={exportExcel}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-file-excel"></i> Export Excel
                    </button>

                    <button
                      onClick={printData}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-print"></i> Print
                    </button>

                    <button
                      onClick={exportPDF}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-file-pdf"></i> Export PDF
                    </button>

                    <div className="dropdown mt-lg-2 mb-lg-2">
                      <button
                        className="btn Export-Btn dropdown-toggle"
                        type="button"
                        id="dropdownMenuButton"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <i className="fa fa-columns"></i> Column Visibility
                      </button>
                      <div
                        className="dropdown-menu pointer-event"
                        aria-labelledby="dropdownMenuButton"
                      >
                        {Object.keys(columnsVisibility).map((col) => (
                          <div
                            key={col}
                            className="dropdown-item d-flex align-items-center"
                          >
                            <input
                              type="checkbox"
                              checked={columnsVisibility[col]}
                              onChange={() => toggleColumn(col)}
                              className="mr-2"
                            />
                            {col.replace(/([A-Z])/g, " $1").toUpperCase()}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div id="table-container" style={{ overflowX: "auto" }}>
                  <table
                    id="example1"
                    className="table table-bordered table-hover"
                  >
                    <thead>
                      <tr>
                        {columnsVisibility.date && <th>Date</th>}
                        {columnsVisibility.account && <th>Account</th>}
                        {columnsVisibility.description && <th>Description</th>}
                        {columnsVisibility.paymentMethod && (
                          <th>Payment Method</th>
                        )}
                        {columnsVisibility.paymentDetails && (
                          <th>Payment Details</th>
                        )}
                        {columnsVisibility.debit && <th>Debit</th>}
                        {columnsVisibility.credit && <th>Credit</th>}
                        {columnsVisibility.accountBalance && (
                          <th>Account Balance</th>
                        )}
                        {columnsVisibility.totalBalance && (
                          <th>Total Balance</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {transactions
                        .slice(startIndex, endIndex)
                        .map((transaction) => (
                          <tr key={transaction.id}>
                            {columnsVisibility.date && (
                              <td>{transaction.date}</td>
                            )}
                            {columnsVisibility.account && (
                              <td>{transaction.account}</td>
                            )}
                            {columnsVisibility.description && (
                              <td>{transaction.description}</td>
                            )}
                            {columnsVisibility.paymentMethod && (
                              <td>{transaction.paymentMethod}</td>
                            )}
                            {columnsVisibility.paymentDetails && (
                              <td>{transaction.paymentDetails}</td>
                            )}
                            {columnsVisibility.debit && (
                              <td>{transaction.debit}</td>
                            )}
                            {columnsVisibility.credit && (
                              <td>{transaction.credit}</td>
                            )}
                            {columnsVisibility.accountBalance && (
                              <td>{transaction.accountBalance}</td>
                            )}
                            {columnsVisibility.totalBalance && (
                              <td>{transaction.totalBalance}</td>
                            )}
                          </tr>
                        ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-gray font-17 footer-total text-center">
                        <td
                          colSpan={columnsVisibility.debit ? 5 : 4}
                          rowSpan={1}
                        >
                          <strong>Total:</strong>
                        </td>
                        {columnsVisibility.debit && (
                          <td
                            className="footer_total_debit"
                            rowSpan={1}
                            colSpan={1}
                          >
                            $
                            {transactions
                              .reduce(
                                (acc, transaction) =>
                                  acc + (transaction.debit || 0),
                                0
                              )
                              .toFixed(2)}
                          </td>
                        )}
                        {columnsVisibility.credit && (
                          <td
                            className="footer_total_credit"
                            rowSpan={1}
                            colSpan={1}
                          >
                            $
                            {transactions
                              .reduce(
                                (acc, transaction) =>
                                  acc + (transaction.credit || 0),
                                0
                              )
                              .toFixed(2)}
                          </td>
                        )}
                        <td
                          colSpan={columnsVisibility.action ? 2 : 1}
                          rowSpan={1}
                        ></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* {modalType && (
          <div
            className="modal fade show"
            id="transactionModal"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="transactionModalLabel"
            aria-hidden={!modalType}
            style={{ display: modalType ? "block" : "none" }}
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="transactionModalLabel">
                    {modalType === "add"
                      ? "Add Transaction"
                      : modalType === "edit"
                      ? "Edit Transaction"
                      : "View Transaction"}
                  </h5>
                  <button
                    type="button"
                    className="close"
                    onClick={closeModal}
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleSaveTransaction();
                    }}
                  >
                    {(modalType === "add" || modalType === "edit") && (
                      <div>
                        <div className="form-group">
                          <label htmlFor="date">Date</label>
                          <input
                            type="date"
                            className="form-control"
                            id="date"
                            value={formData.date}
                            onChange={handleFormChange}
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="account">Account</label>
                          <input
                            type="text"
                            className="form-control"
                            id="account"
                            value={formData.account}
                            onChange={handleFormChange}
                            placeholder="Enter account name"
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="description">Description</label>
                          <input
                            type="text"
                            className="form-control"
                            id="description"
                            value={formData.description}
                            onChange={handleFormChange}
                            placeholder="Enter description"
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="paymentMethod">Payment Method</label>
                          <input
                            type="text"
                            className="form-control"
                            id="paymentMethod"
                            value={formData.paymentMethod}
                            onChange={handleFormChange}
                            placeholder="Enter payment method"
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="paymentDetails">
                            Payment Details
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="paymentDetails"
                            value={formData.paymentDetails}
                            onChange={handleFormChange}
                            placeholder="Enter payment details"
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="debit">Debit</label>
                          <input
                            type="number"
                            className="form-control"
                            id="debit"
                            value={formData.debit}
                            onChange={handleFormChange}
                            placeholder="Enter debit amount"
                          />
                        </div>
                        <div className="form-group">
                          <label htmlFor="credit">Credit</label>
                          <input
                            type="number"
                            className="form-control"
                            id="credit"
                            value={formData.credit}
                            onChange={handleFormChange}
                            placeholder="Enter credit amount"
                          />
                        </div>
                      </div>
                    )}

                    {modalType === "view" && currentTransaction && (
                      <div>
                        <p>
                          <strong>Date:</strong> {currentTransaction.date}
                        </p>
                        <p>
                          <strong>Account:</strong> {currentTransaction.account}
                        </p>
                        <p>
                          <strong>Description:</strong>{" "}
                          {currentTransaction.description}
                        </p>
                        <p>
                          <strong>Payment Method:</strong>{" "}
                          {currentTransaction.paymentMethod}
                        </p>
                        <p>
                          <strong>Payment Details:</strong>{" "}
                          {currentTransaction.paymentDetails}
                        </p>
                        <p>
                          <strong>Debit:</strong> {currentTransaction.debit}
                        </p>
                        <p>
                          <strong>Credit:</strong> {currentTransaction.credit}
                        </p>
                        <p>
                          <strong>Account Balance:</strong>{" "}
                          {currentTransaction.accountBalance}
                        </p>
                        <p>
                          <strong>Total Balance:</strong>{" "}
                          {currentTransaction.totalBalance}
                        </p>
                      </div>
                    )}
                    <div className="modal-footer">
                      {modalType === "add" || modalType === "edit" ? (
                        <>
                          <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={closeModal}
                          >
                            Close
                          </button>
                          <button type="submit" className="btn btn-primary">
                            Save
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          className="btn btn-secondary"
                          onClick={closeModal}
                        >
                          Close
                        </button>
                      )}
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        )} */}
      </div>
    </div>
  );
};

export default CashFlow;
