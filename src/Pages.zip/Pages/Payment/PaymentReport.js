import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../../assets/dist/css/adminlte.min.css";
import "../../assets/plugins/fontawesome-free/css/all.min.css";
import "../../assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css";
import "../../assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css";
import "../../assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css";
import { saveAs } from "file-saver";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import $ from "jquery";

const PaymentReport = () => {
  const [payments, setPayments] = useState([]);
  const [columnsVisibility, setColumnsVisibility] = useState({
    date: true,
    paymentRefNo: true,
    invoiceRefNo: true,
    amount: true,
    paymentType: true,
    account: true,
    description: true,
    action: true,
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(25);

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BASE_URL}/paymentsReport/getall`
        );
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        if (Array.isArray(data)) {
          setPayments(data);
        } else {
          console.error("Fetched data is not an array");
          setPayments([]);
        }
      } catch (error) {
        console.error("Error fetching payments:", error);
        setPayments([]);
      }

      const script = document.createElement("script");
      script.src = "js/JqueryContent.js";
      script.async = true;

      document.body.appendChild(script);

      return () => {
        document.body.removeChild(script);
      };
    };

    fetchPayments();
  }, []);

  const exportCSV = () => {
    const csvData = payments.map((payment) => ({
      Date: payment.date,
      PaymentRefNo: payment.paymentRefNo,
      InvoiceRefNo: payment.invoiceRefNo,
      Amount: payment.amount,
      PaymentType: payment.paymentType,
      Account: payment.account,
      Description: payment.description,
    }));

    const csv = [
      [
        "Date",
        "Payment Ref No",
        "Invoice Ref No",
        "Amount",
        "Payment Type",
        "Account",
        "Description",
      ],
      ...csvData.map((row) => Object.values(row)),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    saveAs(blob, "payments.csv");
  };

  const exportExcel = () => {
    const ws = XLSX.utils.json_to_sheet(
      payments.map((payment) => ({
        Date: payment.date,
        PaymentRefNo: payment.paymentRefNo,
        InvoiceRefNo: payment.invoiceRefNo,
        Amount: payment.amount,
        PaymentType: payment.paymentType,
        Account: payment.account,
        Description: payment.description,
      }))
    );
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Payments");
    XLSX.writeFile(wb, "payments.xlsx");
  };

  const exportPDF = () => {
    const doc = new jsPDF();

    // Define the column headers
    const headers = [
      "Date",
      "Payment Ref No",
      "Invoice Ref No",
      "Amount",
      "Payment Type",
      "Account",
      "Description",
    ];

    // Prepare the data
    const body = payments
      .slice(startIndex, endIndex)
      .map((payment) => [
        payment.date,
        payment.paymentRefNo,
        payment.invoiceRefNo,
        payment.amount,
        payment.paymentType,
        payment.account,
        payment.description,
      ]);

    // Add some space before the table
    doc.text("Payments List", 14, 20); // Title with a slight offset
    doc.setFontSize(12);
    doc.text("Below is the list of payments:", 14, 30);

    // Generate the PDF table with custom styles
    doc.autoTable({
      head: [headers],
      body: body,
      theme: "grid",
      styles: {
        fontSize: 10,
        cellPadding: 3,
        valign: "middle",
        halign: "center",
        overflow: "linebreak",
      },
      headStyles: {
        fillColor: [22, 160, 133], // Bootstrap success color
        textColor: [255, 255, 255], // White text
        fontStyle: "bold",
      },
      alternateRowStyles: {
        fillColor: [240, 240, 240], // Light gray for alternate rows
      },
      margin: { top: 50 }, // Increase top margin for more space above the table
    });

    // Calculate total amount
    const totalAmount = payments
      .reduce((acc, payment) => acc + (payment.amount || 0), 0)
      .toFixed(2);

    // Add total to the PDF
    doc.text(
      `Total Amount: $${totalAmount}`,
      14,
      doc.autoTable.previous.finalY + 10
    );

    // Save the PDF
    doc.save("PaymentsList.pdf");
  };

  const toggleColumn = (column) => {
    setColumnsVisibility((prev) => ({
      ...prev,
      [column]: !prev[column],
    }));
  };

  const printData = () => {
    const printWindow = window.open("", "_blank", "width=800,height=600");
    const tableContent = `
      <html>
        <head>
          <title>Print Table</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            th { background-color: #f2f2f2; }
            th, td { text-align: left; }
          </style>
        </head>
        <body>
          <h2>Payment Report</h2>
          <table>
            <thead>
              <tr>
                ${columnsVisibility.date ? "<th>Date</th>" : ""}
                ${columnsVisibility.account ? "<th>Account</th>" : ""}
                ${columnsVisibility.description ? "<th>Description</th>" : ""}
                ${
                  columnsVisibility.paymentMethod
                    ? "<th>Payment Method</th>"
                    : ""
                }
                ${
                  columnsVisibility.paymentDetails
                    ? "<th>Payment Details</th>"
                    : ""
                }
                ${columnsVisibility.debit ? "<th>Debit</th>" : ""}
                ${columnsVisibility.credit ? "<th>Credit</th>" : ""}
                ${
                  columnsVisibility.accountBalance
                    ? "<th>Account Balance</th>"
                    : ""
                }
                ${
                  columnsVisibility.totalBalance ? "<th>Total Balance</th>" : ""
                }
              </tr>
            </thead>
            <tbody>
              ${payments
                .slice(startIndex, endIndex)
                .map(
                  (payments) => `
                <tr>
                  ${columnsVisibility.date ? `<td>${payments.date}</td>` : ""}
                  ${
                    columnsVisibility.account
                      ? `<td>${payments.account}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.description
                      ? `<td>${payments.description}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.paymentMethod
                      ? `<td>${payments.paymentMethod}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.paymentDetails
                      ? `<td>${payments.paymentDetails}</td>`
                      : ""
                  }
                  ${columnsVisibility.debit ? `<td>${payments.debit}</td>` : ""}
                  ${
                    columnsVisibility.credit
                      ? `<td>${payments.credit}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.accountBalance
                      ? `<td>${payments.accountBalance}</td>`
                      : ""
                  }
                  ${
                    columnsVisibility.totalBalance
                      ? `<td>${payments.totalBalance}</td>`
                      : ""
                  }
                </tr>
              `
                )
                .join("")}
            </tbody>
          </table>
        </body>
      </html>
    `;

    printWindow.document.write(tableContent);
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
  };

  const handleEntriesChange = (e) => {
    setEntriesPerPage(Number(e.target.value));
    setCurrentPage(1);
  };

  const startIndex = (currentPage - 1) * entriesPerPage;
  const endIndex = startIndex + entriesPerPage;

  return (
    <div className="wrapper">
      <div className="content-wrapper">
        <section className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-12 col-md-6">
                <h1 className=" all-heading">Payment Account report</h1>
              </div>
            </div>
          </div>
        </section>
        <section className="content">
          <div className="container-fluid">
            <div className="card cardHover rounded-4 border-0">
              <div className="card-body">
                <div className="row mb-3 d-flex align-items-center">
                  <div className="col-12 col-md-auto form-group mb-2 d-flex align-items-center text-bold mt-2 mb-2 mr-2">
                    <label htmlFor="entriesPerPage" className="mb-0 mr-2">
                      Show
                    </label>
                    <select
                      id="entriesPerPage"
                      className="form-control form-control-sm mr-2"
                      value={entriesPerPage}
                      onChange={handleEntriesChange}
                    >
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={75}>75</option>
                      <option value={100}>100</option>
                    </select>
                    Entries
                  </div>

                  <div className="col d-flex flex-wrap align-items-center">
                    <button
                      onClick={exportCSV}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-file-csv"></i> Export CSV
                    </button>

                    <button
                      onClick={exportExcel}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-file-excel"></i> Export Excel
                    </button>

                    <button
                      onClick={printData}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-print"></i> Print
                    </button>

                    <button
                      onClick={exportPDF}
                      className="btn Export-Btn mt-2 mb-2 mr-2"
                    >
                      <i className="fa fa-file-pdf"></i> Export PDF
                    </button>

                    <div className="dropdown mt-lg-2 mb-lg-2">
                      <button
                        className="btn Export-Btn dropdown-toggle"
                        type="button"
                        id="dropdownMenuButton"
                        data-toggle="dropdown"
                        aria-haspopup="true"
                        aria-expanded="false"
                      >
                        <i className="fa fa-columns"></i> Column Visibility
                      </button>
                      <div
                        className="dropdown-menu pointer-event"
                        aria-labelledby="dropdownMenuButton"
                      >
                        {Object.keys(columnsVisibility).map((col) => (
                          <div
                            key={col}
                            className="dropdown-item d-flex align-items-center"
                          >
                            <input
                              type="checkbox"
                              checked={columnsVisibility[col]}
                              onChange={() => toggleColumn(col)}
                              className="mr-2"
                            />
                            {col.replace(/([A-Z])/g, " $1").toUpperCase()}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div id="table-container" style={{ overflowX: "auto" }}>
                  <table
                    id="example1"
                    className="table table-bordered table-hover"
                  >
                    <thead>
                      <tr>
                        {columnsVisibility.date && <th>Date</th>}
                        {columnsVisibility.paymentRefNo && (
                          <th>Payment Ref No</th>
                        )}
                        {columnsVisibility.invoiceRefNo && (
                          <th>Invoice Ref No</th>
                        )}
                        {columnsVisibility.amount && <th>Amount</th>}
                        {columnsVisibility.paymentType && <th>Payment Type</th>}
                        {columnsVisibility.account && <th>Account</th>}
                        {columnsVisibility.description && <th>Description</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {payments.slice(startIndex, endIndex).map((payment) => (
                        <tr key={payment.id}>
                          {columnsVisibility.date && <td>{payment.date}</td>}
                          {columnsVisibility.paymentRefNo && (
                            <td>{payment.paymentRefNo}</td>
                          )}
                          {columnsVisibility.invoiceRefNo && (
                            <td>{payment.invoiceRefNo}</td>
                          )}
                          {columnsVisibility.amount && (
                            <td>{payment.amount}</td>
                          )}
                          {columnsVisibility.paymentType && (
                            <td>{payment.paymentType}</td>
                          )}
                          {columnsVisibility.account && (
                            <td>{payment.account}</td>
                          )}
                          {columnsVisibility.description && (
                            <td>{payment.description}</td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default PaymentReport;
